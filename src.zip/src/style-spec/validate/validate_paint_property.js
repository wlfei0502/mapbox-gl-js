
import validateProperty from './validate_property';

export default function validatePaintProperty(options) {
    return validateProperty(options, 'paint');
}
