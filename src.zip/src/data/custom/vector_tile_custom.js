// @flow
module.exports.VectorTile = require('./vectortile.js');
module.exports.VectorTileFeature = require('./vectortilefeature.js');
module.exports.VectorTileLayer = require('./vectortilelayer.js');